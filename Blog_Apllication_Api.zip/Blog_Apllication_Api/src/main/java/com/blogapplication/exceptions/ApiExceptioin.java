package com.blogapplication.exceptions;

public class ApiExceptioin extends RuntimeException {

	public ApiExceptioin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiExceptioin(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
